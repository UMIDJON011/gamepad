package uz.elevate.padmap

import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * O'yin ustidagi tahrirlash oynasi.
 * Har bir qo'shishda AVVAL gamepad tugmasi so'raladi, keyin boshqaruv ekranda paydo bo'ladi.
 */
@SuppressLint("ViewConstructor")
class EditorView(private val svc: OverlayService) : FrameLayout(svc) {

    private enum class Part { BODY, END, PLUS }

    private val d = resources.displayMetrics.density
    private val maps get() = svc.maps

    private var sel: Mapping? = null
    private var selPart = Part.BODY

    private var dragM: Mapping? = null
    private var dragPart = Part.BODY
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false

    // ---- yangi tema ranglari ----
    private val cTap = 0xFF2979FF.toInt()
    private val cSwipe = 0xFFFF6D00.toInt()
    private val cStick = 0xFF00C853.toInt()
    private val cDpad = 0xFFAA00FF.toInt()
    private val cPlus = 0xFF00E676.toInt()
    private val cSel = 0xFFFFD600.toInt()
    private val cBar = 0xF0161A22.toInt()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3 * d; strokeCap = Paint.Cap.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xDDFFFFFF.toInt(); textSize = 10 * d; textAlign = Paint.Align.CENTER
    }

    private val status: LinearLayout
    private val statusText: TextView
    private val statusBtns: LinearLayout
    private val panel: LinearLayout

    init {
        setWillNotDraw(false)
        setBackgroundColor(0x88000000.toInt())

        val top = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = round(cBar, 14f)
        }
        top.addView(btn("+ Tugma", cTap) { addTap() })
        top.addView(btn("+ Shoot-surish", cSwipe) { addSwipe() })
        top.addView(btn("+ Joystik", cStick) { addStick() })
        top.addView(btn("+ D-pad", cDpad) { addDpad() })
        top.addView(btn("⚽ FC Mobile shabloni") { applyPreset() })
        top.addView(btn("✓ Saqlash", 0xFF2E7D32.toInt()) { svc.closeEditor(true) })
        top.addView(btn("Bekor") { svc.closeEditor(false) })
        top.addView(btn("↻ Qayta ulash") { svc.reconnect() })
        top.addView(btn("✕ Chiqish", 0xFFC62828.toInt()) { svc.closeEditor(false); svc.stopSelf() })
        addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(top) },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = (8 * d).toInt() })

        statusText = TextView(context).apply {
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
        }
        statusBtns = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, (10 * d).toInt(), 0, 0)
        }
        status = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding((22 * d).toInt(), (16 * d).toInt(), (22 * d).toInt(), (16 * d).toInt())
            background = round(0xF2101318.toInt(), 18f).apply { setStroke((1 * d).toInt(), 0x55FFFFFF) }
            visibility = View.GONE
            addView(statusText); addView(statusBtns)
        }
        addView(status, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        panel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = round(cBar, 14f)
        }
        addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(panel) },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = (10 * d).toInt() })
        select(null)
    }

    private fun round(color: Int, rad: Float = 10f) = GradientDrawable().apply { cornerRadius = rad * d; setColor(color) }

    private fun btn(label: String, color: Int = 0xFF2A303B.toInt(), onClick: () -> Unit) =
        TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            isAllCaps = false
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = round(color)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0) }
        }

    // ================= tugma so'rash =================

    private fun ask(msg: String, mode: Int, skip: String? = null, onSkip: (() -> Unit)? = null, onCode: (Int) -> Unit) {
        statusText.text = msg
        statusBtns.removeAllViews()
        if (skip != null) statusBtns.addView(btn(skip, 0xFF37474F.toInt()) {
            svc.cancelCapture(); hideStatus(); onSkip?.invoke()
        })
        statusBtns.addView(btn("Bekor qilish", 0xFF5D2A2A.toInt()) { svc.cancelCapture(); hideStatus() })
        status.visibility = View.VISIBLE
        svc.capture(mode) { code ->
            hideStatus()
            if (code >= 0) onCode(code) else svc.toast("Gamepad ulanmagan")
        }
    }

    private fun hideStatus() {
        status.visibility = View.GONE
        select(sel, selPart)
    }

    /** Avval asosiy tugma, keyin (ixtiyoriy) kombo tugma */
    private fun askKeyThenMod(title: String, done: (Int, Int) -> Unit) {
        ask("$title\n\nGamepad'da tugmani bosing…", 1) { key ->
            ask("Kombo: shu bilan birga BOSIB TURILADIGAN tugmani bosing\n(kerak bo'lmasa — O'tkazib yuborish)",
                1, "O'tkazib yuborish", { done(key, 0) }) { mod ->
                done(key, if (mod == key) 0 else mod)
            }
        }
    }

    // ================= qo'shish =================

    private fun addTap() = ask("Yangi tugma\n\nGamepad'da tugmani bosing…", 1) { k ->
        val m = Mapping(MType.TAP).apply { key = k; r = 0.06f; x = 0.5f; y = 0.5f }
        maps.add(m); select(m, Part.BODY)
    }

    private fun nextGroup() = (maps.maxOfOrNull { it.group } ?: 0) + 1
    private fun members(g: Int) = maps.filter { it.type == MType.SWIPE && it.group == g }
    private fun groups() = maps.filter { it.type == MType.SWIPE }.groupBy { it.group }.values.toList()

    private fun addSwipe() = askKeyThenMod("Shoot-surish") { k, md ->
        val m = Mapping(MType.SWIPE).apply {
            group = nextGroup(); name = "Shoot"; key = k; mod = md
            x = 0.85f; y = 0.62f; r = 0.075f; x2 = 0.85f; y2 = 0.82f
        }
        maps.add(m); select(m, Part.END)
        svc.toast("Katta doirani Shoot ustiga qo'ying, kichigini surish tomonga")
    }

    private val dirs = listOf(0 to 1, 0 to -1, -1 to 0, 1 to 0, -1 to 1, 1 to 1, -1 to -1, 1 to -1)

    /** "+" bosilganda: shu doira uchun yangi surish tomoni */
    private fun addDirection(g: Int) {
        val f = members(g).firstOrNull() ?: return
        askKeyThenMod("Yangi surish tomoni") { k, md ->
            val n = members(g).size
            val (dx, dy) = dirs[n % dirs.size]
            val m = Mapping(MType.SWIPE).apply {
                group = g; name = f.name; key = k; mod = md; ms = f.ms
                x = f.x; y = f.y; r = f.r
                x2 = (f.x + dx * 0.09f).coerceIn(0f, 1f)
                y2 = (f.y + dy * 0.18f).coerceIn(0f, 1f)
            }
            maps.add(m); select(m, Part.END)
        }
    }

    private fun addStick() = ask("Joystik\n\nStikni bir tomonga oxirigacha suring…", 2) { c ->
        val m = Mapping(MType.STICK).apply {
            ax = c and 0xffff; ay = (c shr 16) and 0xffff
            x = 0.15f; y = 0.70f; r = 0.16f
        }
        maps.add(m); select(m, Part.BODY)
    }

    private fun addDpad() {
        val m = Mapping(MType.DPAD).apply { x = 0.15f; y = 0.70f; r = 0.16f }
        maps.add(m); select(m, Part.BODY)
    }

    private fun applyPreset() {
        maps.clear()
        maps.addAll(Presets.fcMobile())
        select(null)
        svc.toast("FC Mobile shabloni qo'yildi. Tugmalarni o'yindagi joyiga sudrab moslang, keyin Saqlash")
    }

    // ================= tanlash paneli =================

    private fun select(m: Mapping?, part: Part = Part.BODY) {
        sel = m; selPart = part
        panel.removeAllViews()
        if (m == null) {
            panel.addView(btn("Boshqaruvni bosib tanlang • sudrab joyini o'zgartiring • ＋ yangi tomon") {})
            invalidate(); return
        }
        when {
            m.type == MType.TAP -> {
                keyButtons(m)
                sizeButtons(listOf(m), 0.01f, 0.03f, 0.15f)
                panel.addView(btn("🗑 O'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
            m.type == MType.SWIPE && part == Part.BODY -> {
                panel.addView(btn("＋ Surish tomoni", cPlus) { addDirection(m.group) })
                sizeButtons(members(m.group), 0.01f, 0.03f, 0.15f)
                panel.addView(btn("🗑 Doirani o'chirish", 0xFFC62828.toInt()) {
                    maps.removeAll { it.type == MType.SWIPE && it.group == m.group }; select(null)
                })
            }
            m.type == MType.SWIPE -> {
                keyButtons(m)
                panel.addView(btn("Surish: ${m.ms} ms") {
                    m.ms = when (m.ms) { 80 -> 120; 120 -> 180; 180 -> 250; 250 -> 350; else -> 80 }
                    select(m, part)
                })
                panel.addView(btn("🗑 Bu tomonni o'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
            m.type == MType.STICK -> {
                panel.addView(btn("Stik: ${Codes.stickName(m.ax, m.ay)}") {
                    ask("Stikni bir tomonga oxirigacha suring…", 2) { c ->
                        m.ax = c and 0xffff; m.ay = (c shr 16) and 0xffff
                    }
                })
                sizeButtons(listOf(m), 0.02f, 0.05f, 0.4f)
                panel.addView(btn("🗑 O'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
            else -> { // DPAD
                panel.addView(btn("Yo'nalish tugmalari") { captureDpad(m) })
                sizeButtons(listOf(m), 0.02f, 0.05f, 0.4f)
                panel.addView(btn("🗑 O'chirish", 0xFFC62828.toInt()) { maps.remove(m); select(null) })
            }
        }
        invalidate()
    }

    private fun keyButtons(m: Mapping) {
        panel.addView(btn("Tugma: ${Codes.name(m.key)}") {
            ask("Gamepad'da yangi tugmani bosing…", 1) { m.key = it }
        })
        panel.addView(btn(if (m.mod == 0) "Kombo: yo'q" else "Kombo: ${Codes.name(m.mod)} bosib turilsa") {
            ask("Bosib turiladigan (kombo) tugmani bosing…", 1) { if (it != m.key) m.mod = it }
        })
        if (m.mod != 0) panel.addView(btn("Kombo o'chirish") { m.mod = 0; select(m, selPart) })
    }

    private fun sizeButtons(list: List<Mapping>, step: Float, lo: Float, hi: Float) {
        panel.addView(btn("➕ Kattalashtirish") { list.forEach { it.r = (it.r + step).coerceAtMost(hi) }; invalidate() })
        panel.addView(btn("➖ Kichraytirish") { list.forEach { it.r = (it.r - step).coerceAtLeast(lo) }; invalidate() })
    }

    private fun captureDpad(m: Mapping) {
        ask("↑ YUQORI tugmani bosing…", 1) { u ->
            m.up = u
            ask("↓ PAST tugmani bosing…", 1) { dn ->
                m.down = dn
                ask("← CHAP tugmani bosing…", 1) { l ->
                    m.left = l
                    ask("→ O'NG tugmani bosing…", 1) { r -> m.right = r }
                }
            }
        }
    }

    // ================= chizish =================

    private fun minDim() = min(width, height).toFloat()
    private fun rad(m: Mapping) = m.r * minDim()

    private fun keyLabel(m: Mapping) =
        (if (m.mod != 0) Codes.name(m.mod) + "+" else "") + Codes.name(m.key)

    private fun plusPos(f: Mapping): Pair<Float, Float> {
        val r = rad(f) * 0.78f
        return f.x * width + r to f.y * height - r
    }

    private fun disc(c: Canvas, x: Float, y: Float, r: Float, color: Int, selected: Boolean) {
        fill.color = (color and 0x00FFFFFF) or 0x77000000
        c.drawCircle(x, y, r, fill)
        ring.color = if (selected) cSel else (color or 0xFF000000.toInt())
        ring.strokeWidth = (if (selected) 3 else 2) * d
        c.drawCircle(x, y, r, ring)
        ring.color = 0x55FFFFFF
        ring.strokeWidth = 1 * d
        c.drawCircle(x, y, r - 4 * d, ring)
    }

    private fun center(c: Canvas, s: String, x: Float, y: Float) = c.drawText(s, x, y + txt.textSize / 3, txt)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        for (m in maps) {
            if (m.type == MType.SWIPE) continue
            val cx = m.x * w; val cy = m.y * h; val r = rad(m); val s = m === sel
            when (m.type) {
                MType.TAP -> {
                    disc(c, cx, cy, r, cTap, s)
                    center(c, Codes.name(m.key).let { if (m.mod != 0) keyLabel(m) else it }, cx, cy)
                    if (m.name.isNotEmpty()) c.drawText(m.name, cx, cy + r + 13 * d, small)
                }
                MType.STICK -> {
                    disc(c, cx, cy, r, cStick, s)
                    disc(c, cx, cy, r * 0.35f, cStick, false)
                    c.drawText(m.name.ifEmpty { Codes.stickName(m.ax, m.ay) }, cx, cy + r + 13 * d, small)
                }
                MType.DPAD -> {
                    disc(c, cx, cy, r, cDpad, s)
                    center(c, "✚", cx, cy)
                    c.drawText(m.name.ifEmpty { "D-pad" }, cx, cy + r + 13 * d, small)
                }
                else -> {}
            }
        }
        for (g in groups()) {
            val f = g[0]
            val sx = f.x * w; val sy = f.y * h; val r = rad(f)
            for (m in g) {
                val ex = m.x2 * w; val ey = m.y2 * h
                line.color = if (m === sel && selPart == Part.END) cSel else cSwipe
                c.drawLine(sx, sy, ex, ey, line)
                disc(c, ex, ey, 13 * d, cSwipe, m === sel && selPart == Part.END)
                c.drawText(keyLabel(m), ex, ey + 13 * d + 13 * d, small)
            }
            val gs = sel?.let { it.type == MType.SWIPE && it.group == f.group && selPart == Part.BODY } == true
            disc(c, sx, sy, r, cSwipe, gs)
            center(c, f.name.ifEmpty { "Shoot" }, sx, sy)
            val (px, py) = plusPos(f)
            fill.color = cPlus
            c.drawCircle(px, py, 12 * d, fill)
            center(c, "+", px, py)
        }
    }

    // ================= sudrash =================

    private fun hit(x: Float, y: Float): Pair<Mapping, Part>? {
        val w = width.toFloat(); val h = height.toFloat()
        for (g in groups()) {
            val (px, py) = plusPos(g[0])
            if (hypot(x - px, y - py) < 18 * d) return g[0] to Part.PLUS
        }
        for (m in maps.reversed()) {
            if (m.type == MType.SWIPE && hypot(x - m.x2 * w, y - m.y2 * h) < 22 * d) return m to Part.END
        }
        for (m in maps.reversed()) {
            val r = if (m.type == MType.TAP || m.type == MType.SWIPE) max(rad(m), 24 * d) else rad(m)
            if (hypot(x - m.x * w, y - m.y * h) < r) {
                val t = if (m.type == MType.SWIPE) members(m.group).first() else m
                return t to Part.BODY
            }
        }
        return null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (status.visibility == View.VISIBLE) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val h = hit(e.x, e.y)
                if (h == null) { select(null); return true }
                dragM = h.first; dragPart = h.second
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val m = dragM ?: return true
                if (abs(e.x - downX) > 8 * d || abs(e.y - downY) > 8 * d) moved = true
                if (moved && dragPart != Part.PLUS) {
                    val dx = (e.x - lastX) / width
                    val dy = (e.y - lastY) / height
                    lastX = e.x; lastY = e.y
                    when {
                        dragPart == Part.END -> {
                            m.x2 = (m.x2 + dx).coerceIn(0f, 1f); m.y2 = (m.y2 + dy).coerceIn(0f, 1f)
                        }
                        m.type == MType.SWIPE -> members(m.group).forEach {
                            it.x += dx; it.y += dy; it.x2 += dx; it.y2 += dy
                        }
                        else -> {
                            m.x = (m.x + dx).coerceIn(0f, 1f); m.y = (m.y + dy).coerceIn(0f, 1f)
                        }
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val m = dragM
                if (m != null) {
                    if (dragPart == Part.PLUS && !moved) addDirection(m.group)
                    else select(m, if (dragPart == Part.PLUS) Part.BODY else dragPart)
                }
                dragM = null
            }
            MotionEvent.ACTION_CANCEL -> dragM = null
        }
        return true
    }
}
