package uz.elevate.padmap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "uz.elevate.padmap.STOP"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var editor: EditorView? = null
    private var pkg = ""
    var maps: MutableList<Mapping> = mutableListOf()
        private set

    private var pad: IPadService? = null
    private var bound = false

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, PadUserService::class.java.name))
            .daemon(false)
            .processNameSuffix("pad")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, b: IBinder?) {
            if (b != null && b.pingBinder()) {
                pad = IPadService.Stub.asInterface(b)
                main.removeCallbacks(watchdog)
                main.post(watchdog)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            pad = null
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startForegroundCompat()
        val newPkg = intent?.getStringExtra(EXTRA_PKG) ?: pkg
        if (newPkg != pkg) {
            pkg = newPkg
            maps = Profile.load(this, pkg)
            closeEditor(false)
        }
        showBubble()
        bindPad()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("padmap", "PadMap", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "padmap")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("PadMap ishlayapti")
            .setContentText("Gamepad → ekran")
            .addAction(Notification.Action.Builder(null, "To'xtatish", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, n)
        }
    }

    // ---------------- Shizuku ----------------

    private fun bindPad() {
        if (pad != null) { connectPad(); return }
        if (bound) return
        try {
            if (!Shizuku.pingBinder()) { toast("Shizuku ishlamayapti"); return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku ruxsati berilmagan"); return
            }
            Shizuku.bindUserService(args, conn)
            bound = true
        } catch (t: Throwable) {
            toast("Shizuku xatosi: ${t.message}")
        }
    }

    private var lastStatus = ""

    /** Gamepad har 5 soniyada tekshiriladi: Bluetooth orqali yangi ulansa o'zi ilib oladi */
    private val watchdog = object : Runnable {
        override fun run() {
            connectPad()
            main.postDelayed(this, 5000)
        }
    }

    private fun connectPad() {
        val p = pad ?: return
        thread {
            val r = try { p.start() } catch (t: Throwable) { "ERR:${t.message}" }
            main.post {
                if (r != lastStatus) {
                    lastStatus = r
                    if (r.startsWith("OK:")) toast("🎮 Ulandi: ${r.removePrefix("OK:")}")
                    else toast(r.removePrefix("ERR:"))
                    applyProfile(editor == null)
                }
            }
        }
    }

    fun reconnect() {
        lastStatus = ""
        try { pad?.stop() } catch (_: Exception) {}
        if (pad == null) { bound = false; bindPad() } else connectPad()
    }

    fun applyProfile(enable: Boolean) {
        val p = pad ?: return
        val s = screenSize()
        try {
            p.setProfile(Profile.toJson(maps), s.x, s.y)
            p.setEnabled(enable)
        } catch (_: Exception) {
        }
    }

    fun capture(mode: Int, cb: (Int) -> Unit) {
        val p = pad
        if (p == null) { toast("Shizuku ulanmagan"); cb(-1); return }
        try {
            p.capture(mode, object : ICaptureCallback.Stub() {
                override fun onCaptured(code: Int) { main.post { cb(code) } }
            })
        } catch (e: Exception) {
            cb(-1)
        }
    }

    fun cancelCapture() {
        try { pad?.capture(0, null) } catch (_: Exception) {}
    }

    fun screenSize(): Point {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            Point().also {
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealSize(it)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        main.postDelayed({ applyProfile(editor == null) }, 300)
    }

    // ---------------- Suzuvchi logo ----------------

    private fun overlayParams(w: Int, h: Int, focusable: Boolean = false) =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    private fun showBubble() {
        if (bubble != null) return
        val d = resources.displayMetrics.density
        val size = (44 * d).toInt()
        val v = TextView(this).apply {
            text = "🎮"
            textSize = 18f
            gravity = Gravity.CENTER
            alpha = 0.7f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6161A22.toInt())
                setStroke((2 * d).toInt(), 0xFF2979FF.toInt())
            }
        }
        val lp = overlayParams(size, size).apply { x = (8 * d).toInt(); y = (120 * d).toInt() }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 * d || abs(dy) > 10 * d) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) openEditor()
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    // ---------------- Tahrirlash oynasi ----------------

    fun openEditor() {
        if (editor != null) return
        try { pad?.setEnabled(false) } catch (_: Exception) {}
        val ed = EditorView(this)
        wm.addView(ed, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT))
        editor = ed
        bubble?.visibility = View.GONE
        if (pad == null) toast("Diqqat: Shizuku ulanmagan, tugma tanlab bo'lmaydi")
    }

    fun closeEditor(save: Boolean) {
        val ed = editor ?: return
        cancelCapture()
        try { wm.removeView(ed) } catch (_: Exception) {}
        editor = null
        bubble?.visibility = View.VISIBLE
        if (save) {
            Profile.save(this, pkg, maps)
            toast("Saqlandi")
        } else {
            maps = Profile.load(this, pkg)
        }
        applyProfile(true)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        main.removeCallbacks(watchdog)
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        editor = null; bubble = null
        try { pad?.stop() } catch (_: Exception) {}
        if (bound) try { Shizuku.unbindUserService(args, conn, true) } catch (_: Exception) {}
        super.onDestroy()
    }
}
