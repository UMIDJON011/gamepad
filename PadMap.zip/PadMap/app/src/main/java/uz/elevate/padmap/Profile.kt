package uz.elevate.padmap

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class MType { TAP, SWIPE, STICK, DPAD }

/**
 * Bitta bog'lanish. Koordinatalar ekranga nisbatan ulush (0..1).
 * TAP   – tugma bosilib turganda (x,y) nuqta bosilib turadi
 * SWIPE – (x,y) dan bosib (x2,y2) ga suriladi, tugma qo'yib yuborilguncha ushlab turiladi
 * STICK – analog stik (ax, ay o'qlari) -> markazi (x,y), radiusi r bo'lgan ekran joystigi
 * DPAD  – 4 tugma (up/down/left/right) -> xuddi shu ekran joystigi
 * mod   – kombinatsiya: shu tugma bosib turilgandagina ishlaydi (0 = yo'q)
 */
class Mapping(var type: MType) {
    var key = 0
    var mod = 0
    var x = 0.5f
    var y = 0.5f
    var x2 = 0.5f
    var y2 = 0.7f
    var r = 0.15f
    var ax = 0
    var ay = 1
    var up = Codes.HAT_UP
    var down = Codes.HAT_DOWN
    var left = Codes.HAT_LEFT
    var right = Codes.HAT_RIGHT
    var ms = 180

    fun toJson(): JSONObject = JSONObject()
        .put("t", type.name).put("key", key).put("mod", mod)
        .put("x", x.toDouble()).put("y", y.toDouble())
        .put("x2", x2.toDouble()).put("y2", y2.toDouble())
        .put("r", r.toDouble()).put("ax", ax).put("ay", ay)
        .put("up", up).put("down", down).put("left", left).put("right", right)
        .put("ms", ms)

    companion object {
        fun fromJson(o: JSONObject): Mapping = Mapping(MType.valueOf(o.optString("t", "TAP"))).apply {
            key = o.optInt("key")
            mod = o.optInt("mod")
            x = o.optDouble("x", 0.5).toFloat()
            y = o.optDouble("y", 0.5).toFloat()
            x2 = o.optDouble("x2", 0.5).toFloat()
            y2 = o.optDouble("y2", 0.7).toFloat()
            r = o.optDouble("r", 0.15).toFloat()
            ax = o.optInt("ax", 0)
            ay = o.optInt("ay", 1)
            up = o.optInt("up", Codes.HAT_UP)
            down = o.optInt("down", Codes.HAT_DOWN)
            left = o.optInt("left", Codes.HAT_LEFT)
            right = o.optInt("right", Codes.HAT_RIGHT)
            ms = o.optInt("ms", 180)
        }
    }
}

object Profile {
    fun toJson(list: List<Mapping>): String =
        JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()

    fun fromJson(s: String?): MutableList<Mapping> {
        val out = mutableListOf<Mapping>()
        if (s.isNullOrEmpty()) return out
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) out.add(Mapping.fromJson(a.getJSONObject(i)))
        } catch (_: Exception) {
        }
        return out
    }

    private fun prefs(c: Context) = c.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    fun load(c: Context, pkg: String) = fromJson(prefs(c).getString(pkg, null))
    fun save(c: Context, pkg: String, list: List<Mapping>) =
        prefs(c).edit().putString(pkg, toJson(list)).apply()
}

/** Linux input kodlari + bizning virtual kodlar. */
object Codes {
    const val HAT_UP = 1001
    const val HAT_DOWN = 1002
    const val HAT_LEFT = 1003
    const val HAT_RIGHT = 1004
    /** Analog o'q (masalan trigger) tugma sifatida: ABS_BTN + absCode */
    const val ABS_BTN = 2000

    fun name(c: Int): String = when (c) {
        0 -> "—"
        304 -> "A"
        305 -> "B"
        306 -> "C"
        307 -> "X"
        308 -> "Y"
        309 -> "Z"
        310 -> "LB"
        311 -> "RB"
        312 -> "LT"
        313 -> "RT"
        314 -> "SELECT"
        315 -> "START"
        316 -> "HOME"
        317 -> "L3"
        318 -> "R3"
        544, HAT_UP -> "↑"
        545, HAT_DOWN -> "↓"
        546, HAT_LEFT -> "←"
        547, HAT_RIGHT -> "→"
        ABS_BTN + 2 -> "L2"
        ABS_BTN + 5 -> "R2"
        ABS_BTN + 9 -> "RT"
        ABS_BTN + 10 -> "LT"
        else -> if (c >= ABS_BTN) "AXIS${c - ABS_BTN}" else "K$c"
    }

    fun stickName(ax: Int, ay: Int): String = when (ax) {
        0 -> "Chap stik"
        2, 3 -> "O'ng stik"
        else -> "Stik $ax/$ay"
    }
}
