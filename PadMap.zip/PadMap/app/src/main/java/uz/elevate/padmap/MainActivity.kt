package uz.elevate.padmap

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private lateinit var status: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnShizuku: Button
    private val apps = ArrayList<AppItem>()
    private lateinit var adapter: BaseAdapter

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (12 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 14f }
        btnOverlay = Button(this).apply {
            text = "1. Ekran ustida ko'rsatish ruxsati"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        btnShizuku = Button(this).apply {
            text = "2. Shizuku ruxsati"
            setOnClickListener { requestShizuku() }
        }
        val hint = TextView(this).apply {
            textSize = 13f
            text = "O'yinni shu ro'yxatdan oching. O'yin ustida 🎮 logo chiqadi — bossangiz tugma qo'shasiz."
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val list = ListView(this)
        adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = (cv as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, pad / 2, 0, pad / 2)
                    addView(ImageView(context), LinearLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt()))
                    addView(TextView(context).apply { textSize = 16f; setPadding(pad, 0, 0, 0) })
                }
                (row.getChildAt(0) as ImageView).setImageDrawable(apps[p].icon)
                (row.getChildAt(1) as TextView).text = apps[p].label
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, p, _ -> launch(apps[p]) }

        root.addView(status)
        root.addView(btnOverlay)
        root.addView(btnShizuku)
        root.addView(hint)
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    private fun shizukuOk(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        val shz = shizukuOk()
        btnOverlay.isEnabled = !overlay
        btnShizuku.isEnabled = running && !shz
        status.text = buildString {
            append(if (overlay) "✅ Ekran ustida ko'rsatish\n" else "❌ Ekran ustida ko'rsatish ruxsati yo'q\n")
            append(
                when {
                    shz -> "✅ Shizuku ulandi"
                    running -> "❌ Shizuku ruxsati berilmagan"
                    else -> "❌ Shizuku ishlamayapti — Shizuku ilovasini o'rnatib, ishga tushiring"
                }
            )
        }
    }

    private fun requestShizuku() {
        try {
            if (Shizuku.isPreV11()) { toast("Shizuku juda eski, yangilang"); return }
            Shizuku.requestPermission(1)
        } catch (t: Throwable) {
            toast("Shizuku ishlamayapti")
        }
    }

    private fun loadApps() {
        thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val res = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedWith(compareBy({ !it.pkg.contains("fc", true) && !it.pkg.contains("ea.gp", true) }, { it.label.lowercase() }))
            runOnUiThread {
                apps.clear(); apps.addAll(res); adapter.notifyDataSetChanged()
            }
        }
    }

    private fun launch(a: AppItem) {
        if (!Settings.canDrawOverlays(this)) { toast("Avval ekran ustida ko'rsatish ruxsatini bering"); return }
        if (!shizukuOk()) toast("Shizuku ulanmagan — logo chiqadi, lekin gamepad ishlamaydi")
        startForegroundService(Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_PKG, a.pkg))
        val li = packageManager.getLaunchIntentForPackage(a.pkg)
        if (li != null) startActivity(li) else toast("Ilovani ochib bo'lmadi")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
