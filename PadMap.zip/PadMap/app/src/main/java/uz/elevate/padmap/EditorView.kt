package uz.elevate.padmap

import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/** O'yin ustida ochiladigan tahrirlash oynasi: tugmalarni qo'shish, sudrab joylash, gamepad tugmasini tanlash. */
@SuppressLint("ViewConstructor")
class EditorView(private val svc: OverlayService) : FrameLayout(svc) {

    private val d = resources.displayMetrics.density
    private val maps get() = svc.maps
    private var sel: Mapping? = null

    private var dragM: Mapping? = null
    private var dragEnd = false
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }

    private val status: TextView
    private val panel: LinearLayout

    init {
        setWillNotDraw(false)
        setBackgroundColor(0x55000000)

        val top = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(btn("+ Tugma") { add(Mapping(MType.TAP)) })
        top.addView(btn("+ Shoot-surish") {
            add(Mapping(MType.SWIPE).apply { x = 0.82f; y = 0.62f; x2 = 0.82f; y2 = 0.82f })
        })
        top.addView(btn("+ Joystik") { add(Mapping(MType.STICK).apply { x = 0.17f; y = 0.68f }) })
        top.addView(btn("+ D-pad") { add(Mapping(MType.DPAD).apply { x = 0.17f; y = 0.68f }) })
        top.addView(btn("✓ Saqlash", 0xFF43A047.toInt()) { svc.closeEditor(true) })
        top.addView(btn("Bekor") { svc.closeEditor(false) })
        top.addView(btn("Qayta ulash") { svc.reconnect() })
        top.addView(btn("✕ O'chirish", 0xFFE53935.toInt()) { svc.closeEditor(false); svc.stopSelf() })
        addView(HorizontalScrollView(context).apply { addView(top) },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = (8 * d).toInt() })

        status = TextView(context).apply {
            setTextColor(Color.WHITE); textSize = 16f; visibility = View.GONE
            setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
            background = round(0xEE000000.toInt())
        }
        addView(status, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        panel = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        addView(HorizontalScrollView(context).apply { addView(panel) },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = (10 * d).toInt() })
        select(null)
    }

    private fun round(color: Int) = GradientDrawable().apply { cornerRadius = 10 * d; setColor(color) }

    private fun btn(label: String, color: Int = 0xEE263238.toInt(), onClick: () -> Unit) =
        TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = round(color)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0) }
        }

    // ---------------- qo'shish va tanlash ----------------

    private fun add(m: Mapping) {
        maps.add(m)
        select(m)
        when (m.type) {
            MType.TAP, MType.SWIPE -> captureKey(m)
            MType.STICK -> captureStick(m)
            MType.DPAD -> {} // standart: gamepad krestovinasi
        }
    }

    private fun ask(msg: String, mode: Int, cb: (Int) -> Unit) {
        status.text = msg
        status.visibility = View.VISIBLE
        svc.capture(mode) { code ->
            status.visibility = View.GONE
            if (code >= 0) cb(code)
            select(sel)
        }
    }

    private fun captureKey(m: Mapping) = ask("Gamepad'da tugmani bosing…", 1) { m.key = it }

    private fun captureMod(m: Mapping) =
        ask("Bosib turiladigan (kombo) tugmani bosing…", 1) { if (it != m.key) m.mod = it }

    private fun captureStick(m: Mapping) =
        ask("Stikni bir tomonga oxirigacha suring…", 2) {
            m.ax = it and 0xffff; m.ay = (it shr 16) and 0xffff
        }

    private fun captureDpad(m: Mapping) {
        ask("↑ YUQORI tugmani bosing…", 1) { u ->
            m.up = u
            ask("↓ PAST tugmani bosing…", 1) { dn ->
                m.down = dn
                ask("← CHAP tugmani bosing…", 1) { l ->
                    m.left = l
                    ask("→ O'NG tugmani bosing…", 1) { r -> m.right = r }
                }
            }
        }
    }

    private fun select(m: Mapping?) {
        sel = m
        panel.removeAllViews()
        if (m == null) {
            panel.addView(btn("Tugmani tanlash uchun ustiga bosing, joyini sudrab o'zgartiring") {})
            invalidate(); return
        }
        when (m.type) {
            MType.TAP, MType.SWIPE -> {
                panel.addView(btn("Tugma: ${Codes.name(m.key)}") { captureKey(m) })
                panel.addView(btn(if (m.mod == 0) "Kombo: yo'q" else "Kombo: ${Codes.name(m.mod)} bosib turilsa") { captureMod(m) })
                if (m.mod != 0) panel.addView(btn("Kombo o'chirish") { m.mod = 0; select(m) })
                if (m.type == MType.SWIPE) {
                    panel.addView(btn("Surish: ${m.ms} ms") {
                        m.ms = when (m.ms) { 80 -> 120; 120 -> 180; 180 -> 250; 250 -> 350; else -> 80 }
                        select(m)
                    })
                }
            }
            MType.STICK -> {
                panel.addView(btn("Stik: ${Codes.stickName(m.ax, m.ay)}") { captureStick(m) })
                sizeButtons(m)
            }
            MType.DPAD -> {
                panel.addView(btn("Yo'nalish tugmalari") { captureDpad(m) })
                sizeButtons(m)
            }
        }
        panel.addView(btn("O'chirish", 0xFFE53935.toInt()) { maps.remove(m); select(null) })
        invalidate()
    }

    private fun sizeButtons(m: Mapping) {
        panel.addView(btn("Kattaroq") { m.r = (m.r + 0.02f).coerceAtMost(0.4f); invalidate() })
        panel.addView(btn("Kichikroq") { m.r = (m.r - 0.02f).coerceAtLeast(0.04f); invalidate() })
    }

    // ---------------- chizish ----------------

    private fun bigR(m: Mapping) = m.r * min(width, height)

    private fun label(m: Mapping) =
        (if (m.mod != 0) Codes.name(m.mod) + "+" else "") + Codes.name(m.key)

    private fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int, lbl: String, selected: Boolean) {
        fill.color = color
        c.drawCircle(x, y, r, fill)
        stroke.color = if (selected) Color.YELLOW else Color.WHITE
        c.drawCircle(x, y, r, stroke)
        if (lbl.isNotEmpty()) c.drawText(lbl, x, y + text.textSize / 3, text)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        val small = 26 * d
        for (m in maps) {
            val cx = m.x * w; val cy = m.y * h; val s = m === sel
            when (m.type) {
                MType.TAP -> circle(c, cx, cy, small, 0x991E88E5.toInt(), label(m), s)
                MType.SWIPE -> {
                    val ex = m.x2 * w; val ey = m.y2 * h
                    stroke.color = 0xFFFB8C00.toInt()
                    c.drawLine(cx, cy, ex, ey, stroke)
                    circle(c, ex, ey, 12 * d, 0xCCFB8C00.toInt(), "", s)
                    circle(c, cx, cy, small, 0x99FB8C00.toInt(), label(m), s)
                }
                MType.STICK -> {
                    circle(c, cx, cy, bigR(m), 0x5543A047, Codes.stickName(m.ax, m.ay), s)
                    circle(c, cx, cy, 6 * d, 0xFF43A047.toInt(), "", s)
                }
                MType.DPAD -> {
                    circle(c, cx, cy, bigR(m), 0x558E24AA, "D-pad", s)
                    circle(c, cx, cy, 6 * d, 0xFF8E24AA.toInt(), "", s)
                }
            }
        }
    }

    // ---------------- sudrash ----------------

    private fun hit(x: Float, y: Float): Pair<Mapping, Boolean>? {
        val w = width.toFloat(); val h = height.toFloat()
        for (m in maps.reversed()) {
            if (m.type == MType.SWIPE && hypot(x - m.x2 * w, y - m.y2 * h) < 22 * d) return m to true
            val r = if (m.type == MType.STICK || m.type == MType.DPAD) bigR(m) else 30 * d
            if (hypot(x - m.x * w, y - m.y * h) < r) return m to false
        }
        return null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val h = hit(e.x, e.y)
                if (h == null) { select(null); return true }
                dragM = h.first; dragEnd = h.second
                downX = e.x; downY = e.y; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val m = dragM ?: return true
                if (abs(e.x - downX) > 8 * d || abs(e.y - downY) > 8 * d) moved = true
                if (moved) {
                    val fx = (e.x / width).coerceIn(0f, 1f)
                    val fy = (e.y / height).coerceIn(0f, 1f)
                    if (dragEnd) { m.x2 = fx; m.y2 = fy }
                    else {
                        if (m.type == MType.SWIPE) { m.x2 += fx - m.x; m.y2 += fy - m.y }
                        m.x = fx; m.y = fy
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragM?.let { select(it) }
                dragM = null
            }
        }
        return true
    }
}
