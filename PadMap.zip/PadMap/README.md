# PadMap — bepul gamepad keymapper (FC Mobile va boshqa o'yinlar uchun)

## Qanday ishlaydi
- Ilova ichida telefondagi ilovalar ro'yxati bor. O'yinni shu yerdan ochasiz.
- O'yin ustida kichkina 🎮 logo turadi. Uni sudrab joyini o'zgartirsa bo'ladi, bossangiz tahrirlash oynasi ochiladi.
- Gamepad **Shizuku** orqali (adb huquqi, root kerak emas) to'g'ridan-to'g'ri `/dev/input` dan o'qiladi.
  Ekranga multi-touch bosishlar yuboriladi. Gamepad "grab" qilinadi, shuning uchun B tugmasi o'yindan chiqarib yubormaydi.
- O'yin klon qilinmaydi va virtual muhitga solinmaydi. O'zi oddiy ochiladi, shuning uchun har qanday ilova bilan ishlaydi.

## Bog'lanish turlari
| Tur | Nima qiladi |
|---|---|
| **+ Tugma** | Gamepad tugmasi bosilib turganda ekrandagi nuqta ham bosilib turadi |
| **+ Joystik** | Chap/o'ng analog stik → ekrandagi harakat joystigi (radiusini Kattaroq/Kichikroq bilan sozlang) |
| **+ D-pad** | Krestovina → o'sha ekran joystigi |
| **+ Shoot-surish** | Tugma bosilganda to'q sariq nuqtadan bosib, kichik nuqtagacha suradi (FC Mobile'dagi shoot'ni bosib pastga tortish) |
| **Kombo** | Har qanday Tugma/Shoot-surish uchun: "Kombo" tugmasi **bosib turilgandagina** ishlaydi. Masalan: RB bosib turib B bossangiz → shoot'ni pastga tortadi; RB'siz B esa oddiy pass bo'lib qoladi |

L2/R2 kabi analog triggerlar ham tugma sifatida tanlanadi.

## Yig'ish (build)
1. Android Studio'da `PadMap` papkasini oching (Gradle sync o'zi bo'ladi).
2. **Build → Build APK(s)**. APK `app/build/outputs/apk/debug/` ichida chiqadi.

## Telefonda sozlash
1. Play Market'dan **Shizuku**ni o'rnating.
2. Android 11+: Sozlamalar → Dasturchilar uchun → **Simsiz nosozliklarni tuzatish** (Wireless debugging)ni yoqing.
   Shizuku ichida "Pairing" orqali juftlang va **Start** bosing. Kompyuter kerak emas.
   (Telefon qayta yoqilgandan keyin Shizuku'ni qayta Start qilish kerak.)
3. PadMap'ni oching:
   - **1. Ekran ustida ko'rsatish ruxsati** → ruxsat bering
   - **2. Shizuku ruxsati** → Ruxsat berish
4. Gamepadni Bluetooth orqali ulang.
5. Ro'yxatdan FC Mobile'ni bosing. O'yin ochilgach 🎮 logoni bosing:
   - "+ Joystik" → chap stikni suring → doirani o'yin joystigi ustiga qo'ying
   - "+ Tugma" → gamepad tugmasini bosing → doirani Pass/Shoot/Sprint ustiga sudrang
   - "+ Shoot-surish" → tugma bosing → katta nuqtani Shoot ustiga, kichigini pastroqqa qo'ying → kerak bo'lsa "Kombo"
   - **✓ Saqlash**
   Profil har bir o'yin uchun alohida saqlanadi.

## Muammolar
- **"Gamepad topilmadi"**: gamepadni ulab, logo → **Qayta ulash**.
- Joystik teskari yoki noto'g'ri ishlasa: joystikni tanlab "Stik: …" tugmasi bilan qaytadan tanlang.
- Shoot-surish juda tez yoki sekin bo'lsa: "Surish: … ms" tugmasini bosib vaqtini o'zgartiring.

Eslatma: har qanday keymapper o'yin qoidalariga zid deb topilishi mumkin. O'z xavfingizga ishlating.
